gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDNewSpriteObjects1= [];
gdjs.Game_32SceneCode.GDNewSpriteObjects2= [];
gdjs.Game_32SceneCode.GDNewSpriteObjects3= [];
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects3= [];
gdjs.Game_32SceneCode.GDBackgroundsObjects1= [];
gdjs.Game_32SceneCode.GDBackgroundsObjects2= [];
gdjs.Game_32SceneCode.GDBackgroundsObjects3= [];
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDPlayerObjects3= [];
gdjs.Game_32SceneCode.GDText1Objects1= [];
gdjs.Game_32SceneCode.GDText1Objects2= [];
gdjs.Game_32SceneCode.GDText1Objects3= [];
gdjs.Game_32SceneCode.GDText2Objects1= [];
gdjs.Game_32SceneCode.GDText2Objects2= [];
gdjs.Game_32SceneCode.GDText2Objects3= [];
gdjs.Game_32SceneCode.GDText3Objects1= [];
gdjs.Game_32SceneCode.GDText3Objects2= [];
gdjs.Game_32SceneCode.GDText3Objects3= [];
gdjs.Game_32SceneCode.GDText3_95951Objects1= [];
gdjs.Game_32SceneCode.GDText3_95951Objects2= [];
gdjs.Game_32SceneCode.GDText3_95951Objects3= [];
gdjs.Game_32SceneCode.GDText4Objects1= [];
gdjs.Game_32SceneCode.GDText4Objects2= [];
gdjs.Game_32SceneCode.GDText4Objects3= [];
gdjs.Game_32SceneCode.GDText4_95951Objects1= [];
gdjs.Game_32SceneCode.GDText4_95951Objects2= [];
gdjs.Game_32SceneCode.GDText4_95951Objects3= [];
gdjs.Game_32SceneCode.GDRead_9595NoteObjects1= [];
gdjs.Game_32SceneCode.GDRead_9595NoteObjects2= [];
gdjs.Game_32SceneCode.GDRead_9595NoteObjects3= [];
gdjs.Game_32SceneCode.GDText4_95952Objects1= [];
gdjs.Game_32SceneCode.GDText4_95952Objects2= [];
gdjs.Game_32SceneCode.GDText4_95952Objects3= [];
gdjs.Game_32SceneCode.GDNoteObjects1= [];
gdjs.Game_32SceneCode.GDNoteObjects2= [];
gdjs.Game_32SceneCode.GDNoteObjects3= [];
gdjs.Game_32SceneCode.GDText4_95953Objects1= [];
gdjs.Game_32SceneCode.GDText4_95953Objects2= [];
gdjs.Game_32SceneCode.GDText4_95953Objects3= [];
gdjs.Game_32SceneCode.GDreadletterObjects1= [];
gdjs.Game_32SceneCode.GDreadletterObjects2= [];
gdjs.Game_32SceneCode.GDreadletterObjects3= [];
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1= [];
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects2= [];
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects3= [];
gdjs.Game_32SceneCode.GDText5Objects1= [];
gdjs.Game_32SceneCode.GDText5Objects2= [];
gdjs.Game_32SceneCode.GDText5Objects3= [];


gdjs.Game_32SceneCode.asyncCallback13040532 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Read_Note"), gdjs.Game_32SceneCode.GDRead_9595NoteObjects3);
gdjs.copyArray(runtimeScene.getObjects("Text4_2"), gdjs.Game_32SceneCode.GDText4_95952Objects3);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRead_9595NoteObjects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRead_9595NoteObjects3[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95952Objects3.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95952Objects3[i].hide(false);
}
}
gdjs.Game_32SceneCode.localVariables.length = 0;
}
gdjs.Game_32SceneCode.idToCallbackMap.set(13040532, gdjs.Game_32SceneCode.asyncCallback13040532);
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.7), (runtimeScene) => (gdjs.Game_32SceneCode.asyncCallback13040532(runtimeScene, asyncObjectsList)), 13040532, asyncObjectsList);
}
}

}


};gdjs.Game_32SceneCode.asyncCallback13040252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Text4_1"), gdjs.Game_32SceneCode.GDText4_95951Objects2);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95951Objects2.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95951Objects2[i].hide(false);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Game_32SceneCode.localVariables.length = 0;
}
gdjs.Game_32SceneCode.idToCallbackMap.set(13040252, gdjs.Game_32SceneCode.asyncCallback13040252);
gdjs.Game_32SceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Game_32SceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.7), (runtimeScene) => (gdjs.Game_32SceneCode.asyncCallback13040252(runtimeScene, asyncObjectsList)), 13040252, asyncObjectsList);
}
}

}


};gdjs.Game_32SceneCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Walk");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Stand");
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getX() > 1280 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationName() != "4" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13030612);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDBackgroundsObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() + (1));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setX(21);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDPlayerObjects1[i].getX() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDPlayerObjects1[k] = gdjs.Game_32SceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationName() != "4" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationName() != "1" ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13031780);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDBackgroundsObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() - (1));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setX(1169);
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Final_Note"), gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Game_32SceneCode.GDNoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Read_Note"), gdjs.Game_32SceneCode.GDRead_9595NoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Text4_3"), gdjs.Game_32SceneCode.GDText4_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text5"), gdjs.Game_32SceneCode.GDText5Objects1);
gdjs.copyArray(runtimeScene.getObjects("readletter"), gdjs.Game_32SceneCode.GDreadletterObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setX(21);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").setAnimationName("1");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText5Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText5Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95953Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95953Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDNoteObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDreadletterObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDreadletterObjects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text1"), gdjs.Game_32SceneCode.GDText1Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText1Objects1[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 0) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text1"), gdjs.Game_32SceneCode.GDText1Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText1Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText1Objects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text2"), gdjs.Game_32SceneCode.GDText2Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText2Objects1[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 1) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text2"), gdjs.Game_32SceneCode.GDText2Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText2Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText2Objects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text3"), gdjs.Game_32SceneCode.GDText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text3_1"), gdjs.Game_32SceneCode.GDText3_95951Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText3Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText3_95951Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText3_95951Objects1[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 2) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text3"), gdjs.Game_32SceneCode.GDText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text3_1"), gdjs.Game_32SceneCode.GDText3_95951Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText3Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText3Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText3_95951Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText3_95951Objects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 3) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text4"), gdjs.Game_32SceneCode.GDText4Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text4_1"), gdjs.Game_32SceneCode.GDText4_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text4_2"), gdjs.Game_32SceneCode.GDText4_95952Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95951Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95951Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95952Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95952Objects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Backgrounds"), gdjs.Game_32SceneCode.GDBackgroundsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDBackgroundsObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDBackgroundsObjects1[i].getBehavior("Animation").getAnimationIndex() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDBackgroundsObjects1[k] = gdjs.Game_32SceneCode.GDBackgroundsObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Text4"), gdjs.Game_32SceneCode.GDText4Objects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4Objects1[i].hide(false);
}
}

{ //Subevents
gdjs.Game_32SceneCode.eventsList1(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Read_Note"), gdjs.Game_32SceneCode.GDRead_9595NoteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[k] = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[k] = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Game_32SceneCode.GDNoteObjects1);
/* Reuse gdjs.Game_32SceneCode.GDRead_9595NoteObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Text4_3"), gdjs.Game_32SceneCode.GDText4_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("readletter"), gdjs.Game_32SceneCode.GDreadletterObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95953Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95953Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDreadletterObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDreadletterObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDNoteObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i].hide();
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Game_32SceneCode.GDNoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("readletter"), gdjs.Game_32SceneCode.GDreadletterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDNoteObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDNoteObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDNoteObjects1[k] = gdjs.Game_32SceneCode.GDNoteObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDNoteObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDreadletterObjects1.length;i<l;++i) {
    if ( !(gdjs.Game_32SceneCode.GDreadletterObjects1[i].getBehavior("ButtonFSM").IsClicked(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDreadletterObjects1[k] = gdjs.Game_32SceneCode.GDreadletterObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDreadletterObjects1.length = k;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Read_Note"), gdjs.Game_32SceneCode.GDRead_9595NoteObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDRead_9595NoteObjects1[i].rotate(gdjs.randomFloatInRange(-(5), 5), runtimeScene);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("readletter"), gdjs.Game_32SceneCode.GDreadletterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDreadletterObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDreadletterObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDreadletterObjects1[k] = gdjs.Game_32SceneCode.GDreadletterObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDreadletterObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Final_Note"), gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Game_32SceneCode.GDNoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Text4_3"), gdjs.Game_32SceneCode.GDText4_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Text5"), gdjs.Game_32SceneCode.GDText5Objects1);
/* Reuse gdjs.Game_32SceneCode.GDreadletterObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText4_95953Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText4_95953Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDreadletterObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDreadletterObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDNoteObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDText5Objects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDText5Objects1[i].hide(false);
}
}
elseEventsChainSatisfied = true;
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects3.length = 0;
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundsObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundsObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GDText1Objects1.length = 0;
gdjs.Game_32SceneCode.GDText1Objects2.length = 0;
gdjs.Game_32SceneCode.GDText1Objects3.length = 0;
gdjs.Game_32SceneCode.GDText2Objects1.length = 0;
gdjs.Game_32SceneCode.GDText2Objects2.length = 0;
gdjs.Game_32SceneCode.GDText2Objects3.length = 0;
gdjs.Game_32SceneCode.GDText3Objects1.length = 0;
gdjs.Game_32SceneCode.GDText3Objects2.length = 0;
gdjs.Game_32SceneCode.GDText3Objects3.length = 0;
gdjs.Game_32SceneCode.GDText3_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDText3_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDText3_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDText4Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4Objects3.length = 0;
gdjs.Game_32SceneCode.GDText4_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length = 0;
gdjs.Game_32SceneCode.GDRead_9595NoteObjects2.length = 0;
gdjs.Game_32SceneCode.GDRead_9595NoteObjects3.length = 0;
gdjs.Game_32SceneCode.GDText4_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDNoteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNoteObjects2.length = 0;
gdjs.Game_32SceneCode.GDNoteObjects3.length = 0;
gdjs.Game_32SceneCode.GDText4_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDreadletterObjects1.length = 0;
gdjs.Game_32SceneCode.GDreadletterObjects2.length = 0;
gdjs.Game_32SceneCode.GDreadletterObjects3.length = 0;
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1.length = 0;
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects2.length = 0;
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects3.length = 0;
gdjs.Game_32SceneCode.GDText5Objects1.length = 0;
gdjs.Game_32SceneCode.GDText5Objects2.length = 0;
gdjs.Game_32SceneCode.GDText5Objects3.length = 0;

gdjs.Game_32SceneCode.eventsList2(runtimeScene);
gdjs.Game_32SceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewSpriteObjects3.length = 0;
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Game_32SceneCode.GDNewTiledSpriteObjects3.length = 0;
gdjs.Game_32SceneCode.GDBackgroundsObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundsObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundsObjects3.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects3.length = 0;
gdjs.Game_32SceneCode.GDText1Objects1.length = 0;
gdjs.Game_32SceneCode.GDText1Objects2.length = 0;
gdjs.Game_32SceneCode.GDText1Objects3.length = 0;
gdjs.Game_32SceneCode.GDText2Objects1.length = 0;
gdjs.Game_32SceneCode.GDText2Objects2.length = 0;
gdjs.Game_32SceneCode.GDText2Objects3.length = 0;
gdjs.Game_32SceneCode.GDText3Objects1.length = 0;
gdjs.Game_32SceneCode.GDText3Objects2.length = 0;
gdjs.Game_32SceneCode.GDText3Objects3.length = 0;
gdjs.Game_32SceneCode.GDText3_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDText3_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDText3_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDText4Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4Objects3.length = 0;
gdjs.Game_32SceneCode.GDText4_95951Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4_95951Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4_95951Objects3.length = 0;
gdjs.Game_32SceneCode.GDRead_9595NoteObjects1.length = 0;
gdjs.Game_32SceneCode.GDRead_9595NoteObjects2.length = 0;
gdjs.Game_32SceneCode.GDRead_9595NoteObjects3.length = 0;
gdjs.Game_32SceneCode.GDText4_95952Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4_95952Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4_95952Objects3.length = 0;
gdjs.Game_32SceneCode.GDNoteObjects1.length = 0;
gdjs.Game_32SceneCode.GDNoteObjects2.length = 0;
gdjs.Game_32SceneCode.GDNoteObjects3.length = 0;
gdjs.Game_32SceneCode.GDText4_95953Objects1.length = 0;
gdjs.Game_32SceneCode.GDText4_95953Objects2.length = 0;
gdjs.Game_32SceneCode.GDText4_95953Objects3.length = 0;
gdjs.Game_32SceneCode.GDreadletterObjects1.length = 0;
gdjs.Game_32SceneCode.GDreadletterObjects2.length = 0;
gdjs.Game_32SceneCode.GDreadletterObjects3.length = 0;
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects1.length = 0;
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects2.length = 0;
gdjs.Game_32SceneCode.GDFinal_9595NoteObjects3.length = 0;
gdjs.Game_32SceneCode.GDText5Objects1.length = 0;
gdjs.Game_32SceneCode.GDText5Objects2.length = 0;
gdjs.Game_32SceneCode.GDText5Objects3.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
