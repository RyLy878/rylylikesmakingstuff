gdjs.Intro_32SceneCode = {};
gdjs.Intro_32SceneCode.localVariables = [];
gdjs.Intro_32SceneCode.idToCallbackMap = new Map();
gdjs.Intro_32SceneCode.GDBackground2Objects1= [];
gdjs.Intro_32SceneCode.GDBackground2Objects2= [];
gdjs.Intro_32SceneCode.GDBackgroundObjects1= [];
gdjs.Intro_32SceneCode.GDBackgroundObjects2= [];
gdjs.Intro_32SceneCode.GDNoteObjects1= [];
gdjs.Intro_32SceneCode.GDNoteObjects2= [];
gdjs.Intro_32SceneCode.GDNote_9595TextObjects1= [];
gdjs.Intro_32SceneCode.GDNote_9595TextObjects2= [];
gdjs.Intro_32SceneCode.GDAcceptObjects1= [];
gdjs.Intro_32SceneCode.GDAcceptObjects2= [];
gdjs.Intro_32SceneCode.GDDeclineObjects1= [];
gdjs.Intro_32SceneCode.GDDeclineObjects2= [];
gdjs.Intro_32SceneCode.GDNewTextObjects1= [];
gdjs.Intro_32SceneCode.GDNewTextObjects2= [];


gdjs.Intro_32SceneCode.asyncCallback12989980 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Intro_32SceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Decline"), gdjs.Intro_32SceneCode.GDDeclineObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("NewText"), gdjs.Intro_32SceneCode.GDNewTextObjects2);

{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects2.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDDeclineObjects2.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDDeclineObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNewTextObjects2.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNewTextObjects2[i].hide(false);
}
}
gdjs.Intro_32SceneCode.localVariables.length = 0;
}
gdjs.Intro_32SceneCode.idToCallbackMap.set(12989980, gdjs.Intro_32SceneCode.asyncCallback12989980);
gdjs.Intro_32SceneCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Intro_32SceneCode.localVariables);
for (const obj of gdjs.Intro_32SceneCode.GDAcceptObjects1) asyncObjectsList.addObject("Accept", obj);
for (const obj of gdjs.Intro_32SceneCode.GDDeclineObjects1) asyncObjectsList.addObject("Decline", obj);
for (const obj of gdjs.Intro_32SceneCode.GDNewTextObjects1) asyncObjectsList.addObject("NewText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(21), (runtimeScene) => (gdjs.Intro_32SceneCode.asyncCallback12989980(runtimeScene, asyncObjectsList)), 12989980, asyncObjectsList);
}
}

}


};gdjs.Intro_32SceneCode.asyncCallback12993988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Intro_32SceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects2);

{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects2.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects2[i].returnVariable(gdjs.Intro_32SceneCode.GDAcceptObjects2[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}
gdjs.Intro_32SceneCode.localVariables.length = 0;
}
gdjs.Intro_32SceneCode.idToCallbackMap.set(12993988, gdjs.Intro_32SceneCode.asyncCallback12993988);
gdjs.Intro_32SceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Intro_32SceneCode.localVariables);
for (const obj of gdjs.Intro_32SceneCode.GDAcceptObjects1) asyncObjectsList.addObject("Accept", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Intro_32SceneCode.asyncCallback12993988(runtimeScene, asyncObjectsList)), 12993988, asyncObjectsList);
}
}

}


};gdjs.Intro_32SceneCode.asyncCallback12995940 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Intro_32SceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects2);

{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects2.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects2[i].returnVariable(gdjs.Intro_32SceneCode.GDAcceptObjects2[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}
gdjs.Intro_32SceneCode.localVariables.length = 0;
}
gdjs.Intro_32SceneCode.idToCallbackMap.set(12995940, gdjs.Intro_32SceneCode.asyncCallback12995940);
gdjs.Intro_32SceneCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Intro_32SceneCode.localVariables);
for (const obj of gdjs.Intro_32SceneCode.GDAcceptObjects1) asyncObjectsList.addObject("Accept", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Intro_32SceneCode.asyncCallback12995940(runtimeScene, asyncObjectsList)), 12995940, asyncObjectsList);
}
}

}


};gdjs.Intro_32SceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decline"), gdjs.Intro_32SceneCode.GDDeclineObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Intro_32SceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Intro_32SceneCode.GDNoteObjects1);
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Animation").setAnimationName("1");
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDDeclineObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDDeclineObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNewTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].returnVariable(gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].returnVariable(gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getVariables().getFromIndex(1)).setBoolean(false);
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNoteObjects1[i].setX(-(112));
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNoteObjects1[i].setY(-(28));
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNoteObjects1[i].getBehavior("LinearMovement").SetSpeedY(-(200), null);
}
}

{ //Subevents
gdjs.Intro_32SceneCode.eventsList0(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Intro_32SceneCode.GDNoteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDNoteObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDNoteObjects1[i].getY() == -(3478) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDNoteObjects1[k] = gdjs.Intro_32SceneCode.GDNoteObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDNoteObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12990932);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Intro_32SceneCode.GDNoteObjects1 */
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNoteObjects1[i].clearForces();
}
}
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNoteObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNoteObjects1[i].setY(-(3478));
}
}
elseEventsChainSatisfied = true;
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Note"), gdjs.Intro_32SceneCode.GDNoteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Note_Text"), gdjs.Intro_32SceneCode.GDNote_9595TextObjects1);
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDNote_9595TextObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDNote_9595TextObjects1[i].setY((( gdjs.Intro_32SceneCode.GDNoteObjects1.length === 0 ) ? 0 :gdjs.Intro_32SceneCode.GDNoteObjects1[0].getPointY("")) + 3843);
}
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12992780);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decline"), gdjs.Intro_32SceneCode.GDDeclineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDDeclineObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDDeclineObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDDeclineObjects1[k] = gdjs.Intro_32SceneCode.GDDeclineObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDDeclineObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDDeclineObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDDeclineObjects1[k] = gdjs.Intro_32SceneCode.GDDeclineObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Animation").getAnimationName() == "1" ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12993660);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Intro_32SceneCode.GDAcceptObjects1 */
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Animation").setAnimationName("2");
}
}

{ //Subevents
gdjs.Intro_32SceneCode.eventsList1(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decline"), gdjs.Intro_32SceneCode.GDDeclineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDDeclineObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDDeclineObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDDeclineObjects1[k] = gdjs.Intro_32SceneCode.GDDeclineObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDDeclineObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDDeclineObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDDeclineObjects1[k] = gdjs.Intro_32SceneCode.GDDeclineObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Animation").getAnimationName() == "2" ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getVariableBoolean(gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12995044);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Intro_32SceneCode.GDAcceptObjects1 */
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Animation").setAnimationName("3");
}
}

{ //Subevents
gdjs.Intro_32SceneCode.eventsList2(runtimeScene);} //End of subevents
elseEventsChainSatisfied = true;
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Accept"), gdjs.Intro_32SceneCode.GDAcceptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Decline"), gdjs.Intro_32SceneCode.GDDeclineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDDeclineObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDDeclineObjects1[i].getBehavior("ButtonFSM").IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDDeclineObjects1[k] = gdjs.Intro_32SceneCode.GDDeclineObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDDeclineObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDDeclineObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDDeclineObjects1[k] = gdjs.Intro_32SceneCode.GDDeclineObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Animation").getAnimationName() == "3" ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Intro_32SceneCode.GDAcceptObjects1.length;i<l;++i) {
    if ( gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getVariableBoolean(gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Intro_32SceneCode.GDAcceptObjects1[k] = gdjs.Intro_32SceneCode.GDAcceptObjects1[i];
        ++k;
    }
}
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12997420);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Intro_32SceneCode.GDAcceptObjects1 */
{for(var i = 0, len = gdjs.Intro_32SceneCode.GDAcceptObjects1.length ;i < len;++i) {
    gdjs.Intro_32SceneCode.GDAcceptObjects1[i].getBehavior("Scale").setScale(17);
}
}
elseEventsChainSatisfied = true;
}

}


};

gdjs.Intro_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Intro_32SceneCode.GDBackground2Objects1.length = 0;
gdjs.Intro_32SceneCode.GDBackground2Objects2.length = 0;
gdjs.Intro_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Intro_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Intro_32SceneCode.GDNoteObjects1.length = 0;
gdjs.Intro_32SceneCode.GDNoteObjects2.length = 0;
gdjs.Intro_32SceneCode.GDNote_9595TextObjects1.length = 0;
gdjs.Intro_32SceneCode.GDNote_9595TextObjects2.length = 0;
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = 0;
gdjs.Intro_32SceneCode.GDAcceptObjects2.length = 0;
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = 0;
gdjs.Intro_32SceneCode.GDDeclineObjects2.length = 0;
gdjs.Intro_32SceneCode.GDNewTextObjects1.length = 0;
gdjs.Intro_32SceneCode.GDNewTextObjects2.length = 0;

gdjs.Intro_32SceneCode.eventsList3(runtimeScene);
gdjs.Intro_32SceneCode.GDBackground2Objects1.length = 0;
gdjs.Intro_32SceneCode.GDBackground2Objects2.length = 0;
gdjs.Intro_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Intro_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Intro_32SceneCode.GDNoteObjects1.length = 0;
gdjs.Intro_32SceneCode.GDNoteObjects2.length = 0;
gdjs.Intro_32SceneCode.GDNote_9595TextObjects1.length = 0;
gdjs.Intro_32SceneCode.GDNote_9595TextObjects2.length = 0;
gdjs.Intro_32SceneCode.GDAcceptObjects1.length = 0;
gdjs.Intro_32SceneCode.GDAcceptObjects2.length = 0;
gdjs.Intro_32SceneCode.GDDeclineObjects1.length = 0;
gdjs.Intro_32SceneCode.GDDeclineObjects2.length = 0;
gdjs.Intro_32SceneCode.GDNewTextObjects1.length = 0;
gdjs.Intro_32SceneCode.GDNewTextObjects2.length = 0;


return;

}

gdjs['Intro_32SceneCode'] = gdjs.Intro_32SceneCode;
